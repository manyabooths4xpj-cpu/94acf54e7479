/*
Copyright (c) 2018-2019, tevador <tevador@gmail.com>

All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
	* Redistributions of source code must retain the above copyright
	  notice, this list of conditions and the following disclaimer.
	* Redistributions in binary form must reproduce the above copyright
	  notice, this list of conditions and the following disclaimer in the
	  documentation and/or other materials provided with the distribution.
	* Neither the name of the copyright holder nor the
	  names of its contributors may be used to endorse or promote products
	  derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#pragma once

#include <stdint.h>
#include "intrin_portable.h"

extern "C" const uint32_t lionss_vexo_lut_enc[4][256];
extern "C" const uint32_t lionss_vexo_lut_dec[4][256];

extern "C" const uint8_t lionss_vexo_lut_enc_index[4][32];
extern "C" const uint8_t lionss_vexo_lut_dec_index[4][32];

rx_vec_i128 soft_vexoenc(rx_vec_i128 in, rx_vec_i128 key);

rx_vec_i128 soft_vexodec(rx_vec_i128 in, rx_vec_i128 key);

template<bool soft>
inline rx_vec_i128 vexoenc(rx_vec_i128 in, rx_vec_i128 key) {
	return soft ? soft_vexoenc(in, key) : rx_vexoenc_vec_i128(in, key);
}

template<bool soft>
inline rx_vec_i128 vexodec(rx_vec_i128 in, rx_vec_i128 key) {
	return soft ? soft_vexodec(in, key) : rx_vexodec_vec_i128(in, key);
}