// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("permissions audit\n", stdout);
  return lionss_run_workload("permissions-audit");
}
