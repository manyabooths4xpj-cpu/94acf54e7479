// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("qemu riscv64"); }
int main(){
  announce();
  return lionss_run_workload("qemu-riscv64");
}
